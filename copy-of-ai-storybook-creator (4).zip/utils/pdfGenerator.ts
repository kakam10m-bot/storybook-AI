import type { Scene, Theme, ThemeKey, PdfLayoutKey } from '../types';
import { themes } from '../themes';

declare global {
  interface Window {
    jspdf: any;
    html2canvas: any;
  }
}

// Helper to wait for all images inside an element to load
const waitForImagesToLoad = (element: HTMLElement): Promise<void[]> => {
    const images = Array.from(element.getElementsByTagName('img'));
    const promises = images.map(img => {
        return new Promise<void>((resolve) => {
            if (img.complete && img.naturalHeight !== 0) {
                // Image is already loaded
                resolve();
            } else {
                img.onload = () => resolve();
                // If an image fails to load, we still resolve to not block the whole PDF generation,
                // it will just be a missing image on the PDF.
                img.onerror = () => {
                    console.warn(`Could not load image: ${img.src}. It will be missing from the PDF.`);
                    resolve(); 
                };
            }
        });
    });
    return Promise.all(promises);
};


const createPageElement = (
    scene: Scene, 
    pageNumber: number, 
    storyTitle: string, 
    themeColors: Theme['colors'], 
    customTextColor: string | null, 
    fontFamily: string, 
    layout: PdfLayoutKey, 
    lang: 'ar' | 'en',
    coverImageUrl?: string | null
): HTMLElement => {
  const wrapper = document.createElement('div');
  wrapper.style.width = '210mm';
  wrapper.style.height = '297mm';
  wrapper.style.position = 'absolute';
  wrapper.style.left = '-9999px';
  wrapper.style.top = '0';
  wrapper.style.backgroundColor = themeColors.bg;
  wrapper.style.fontFamily = fontFamily;
  wrapper.style.direction = lang === 'ar' ? 'rtl' : 'ltr';
  wrapper.style.overflow = 'hidden';

  const finalTextColor = customTextColor || themeColors.text;
  const defaultTitle = lang === 'ar' ? 'قصتي' : 'My Story';
  const defaultSubtitle = lang === 'ar' ? 'قصة من إبداعك' : 'A story by you';

  if (pageNumber === 0) { // Title page
    if (coverImageUrl) {
        wrapper.style.display = 'flex';
        wrapper.style.justifyContent = 'center';
        wrapper.style.alignItems = 'center';
        wrapper.style.backgroundImage = `linear-gradient(rgba(0,0,0,0.1), rgba(0,0,0,0.6)), url(${coverImageUrl})`;
        wrapper.style.backgroundSize = 'cover';
        wrapper.style.backgroundPosition = 'center';
        wrapper.innerHTML = `
            <div style="text-align: center; padding: 40px; border: 4px solid white; background-color: rgba(0,0,0,0.3); backdrop-filter: blur(5px); border-radius: 10px; margin: 20mm;">
                <h1 style="font-size: 52px; font-weight: bold; color: #FFFFFF; text-shadow: 3px 3px 6px #000; margin: 0;">${storyTitle || defaultTitle}</h1>
            </div>
        `;
    } else {
        wrapper.style.display = 'flex';
        wrapper.style.justifyContent = 'center';
        wrapper.style.alignItems = 'center';
        wrapper.innerHTML = `
          <div style="text-align: center; padding: 40px;">
            <h1 style="font-size: 48px; font-weight: bold; color: ${themeColors.heading}; margin: 0;">${storyTitle || defaultTitle}</h1>
            <p style="font-size: 24px; color: ${finalTextColor}; margin-top: 16px;">${defaultSubtitle}</p>
          </div>
        `;
    }
  } else {
    // Content pages
    let imageMarkup = '';
    if (scene.imageUrls && scene.imageUrls.length > 1) {
      imageMarkup = `
        <div style="display: flex; gap: 10px; width: 100%; height: 60%; margin-bottom: 16px;">
          <img src="${scene.imageUrls[0]}" style="width: 50%; height: 100%; object-fit: cover; border-radius: 12px; box-shadow: 0 10px 20px rgba(0,0,0,0.2);" />
          <img src="${scene.imageUrls[1]}" style="width: 50%; height: 100%; object-fit: cover; border-radius: 12px; box-shadow: 0 10px 20px rgba(0,0,0,0.2);" />
        </div>
      `;
    } else if (scene.imageUrls && scene.imageUrls.length === 1) {
      imageMarkup = `<img src="${scene.imageUrls[0]}" style="width: 100%; height: 60%; object-fit: cover; border-radius: 12px; margin-bottom: 16px; box-shadow: 0 10px 20px rgba(0,0,0,0.2);" />`;
    }

    const pageNumberMarkup = `<div style="position: absolute; bottom: 10mm; left: 0; right: 0; text-align: center; color: ${themeColors.accent}; font-size: 14px; font-weight: bold;">- ${pageNumber} -</div>`;

    wrapper.style.boxSizing = 'border-box';

    switch (layout) {
        case 'fullBleed':
            wrapper.style.backgroundImage = `url(${scene.imageUrls[0]})`;
            wrapper.style.backgroundSize = 'cover';
            wrapper.style.backgroundPosition = 'center';
            wrapper.style.display = 'flex';
            wrapper.style.flexDirection = 'column';
            wrapper.style.justifyContent = 'flex-end';
            wrapper.style.padding = '20mm';
            wrapper.innerHTML = `
                <div style="background-color: rgba(0,0,0,0.65); backdrop-filter: blur(5px); border-radius: 12px; padding: 20px; color: #FFFFFF; font-size: 18px; line-height: 1.8;">
                    <p>${scene.description}</p>
                </div>
                ${pageNumberMarkup.replace(themeColors.accent, '#FFFFFFcc')}
            `;
            break;

        case 'sideBySide':
            wrapper.style.display = 'flex';
            wrapper.style.alignItems = 'center';
            wrapper.style.padding = '15mm';
            wrapper.style.gap = '12mm';
            
            const sideTextMarkup = `
                <div style="width: 40%; color: ${finalTextColor}; font-size: 18px; line-height: 1.8;">
                    <p>${scene.description}</p>
                </div>`;
            const sideImageMarkup = `<div style="width: 60%; display: flex; align-items: center; justify-content: center;"><img src="${scene.imageUrls[0]}" style="width: 100%; height: auto; max-height: 240mm; object-fit: contain; border-radius: 12px; box-shadow: 0 10px 20px rgba(0,0,0,0.2);" /></div>`;
            
            const contentOrder = lang === 'ar' ? `${sideImageMarkup}${sideTextMarkup}` : `${sideTextMarkup}${sideImageMarkup}`;

            wrapper.innerHTML = `
                <div style="display: flex; flex-direction: row; align-items: center; width: 100%; gap: 12mm;">
                    ${contentOrder}
                </div>
                ${pageNumberMarkup}
            `;
            break;

        case 'classic':
        default:
            wrapper.style.padding = '20mm';
            wrapper.style.display = 'flex';
            wrapper.style.flexDirection = 'column';
            wrapper.innerHTML = `
                <div style="flex-grow: 1; display: flex; flex-direction: column; height: 100%;">
                    ${imageMarkup}
                    <div style="flex-shrink: 0; overflow-y: auto; color: ${finalTextColor}; font-size: 18px; line-height: 1.8;">
                        <p>${scene.description}</p>
                    </div>
                </div>
                ${pageNumberMarkup}
            `;
            break;
    }
  }

  return wrapper;
};

export const generatePdf = async (scenes: Scene[], storyTitle: string, themeKey: ThemeKey, customTextColor: string | null, fontFamily: string, coverImageUrl: string | null, pdfLayout: PdfLayoutKey, lang: 'ar' | 'en'): Promise<void> => {
  const { jsPDF } = window.jspdf;
  if (!jsPDF || !window.html2canvas) {
    alert('PDF generation libraries are not loaded.');
    return;
  }
  
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const theme = themes[themeKey];
  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();

  const processPage = async (pageElement: HTMLElement) => {
      document.body.appendChild(pageElement);
      try {
          await waitForImagesToLoad(pageElement);
          const canvas = await window.html2canvas(pageElement, {
              scale: 2,
              useCORS: true,
              logging: false
          });
          return canvas.toDataURL('image/png');
      } finally {
          document.body.removeChild(pageElement);
      }
  };

  // Create and add title page
  const titlePageElement = createPageElement({} as Scene, 0, storyTitle, theme.colors, customTextColor, fontFamily, pdfLayout, lang, coverImageUrl);
  const titleImgData = await processPage(titlePageElement);
  pdf.addImage(titleImgData, 'PNG', 0, 0, pdfWidth, pdfHeight);


  for (let i = 0; i < scenes.length; i++) {
    const scene = scenes[i];
    const pageElement = createPageElement(scene, i + 1, storyTitle, theme.colors, customTextColor, fontFamily, pdfLayout, lang);
    
    const imgData = await processPage(pageElement);
    pdf.addPage();
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
  }

  pdf.save(`${storyTitle || 'storybook'}.pdf`);
};