// sw.js

const CACHE_NAME = 'ai-storybook-cache-v2'; // Bumped version to ensure update
const urlsToCache = [
  '/',
  '/index.html',
  '/favicon.svg',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/index.tsx',
];

// Install a service worker
self.addEventListener('install', event => {
  // Perform install steps
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache and caching app shell');
        return cache.addAll(urlsToCache);
      })
      .then(() => self.skipWaiting()) // Activate new service worker immediately
  );
});

// More robust fetch handler
self.addEventListener('fetch', event => {
  // Let the browser do its default thing for non-GET requests.
  if (event.request.method !== 'GET') {
    return;
  }

  const requestUrl = new URL(event.request.url);

  // For requests to other origins (CDNs, fonts, APIs), do not intercept.
  // Let the browser handle them directly. This is safer.
  if (requestUrl.origin !== location.origin) {
    return;
  }
  
  // For same-origin requests, use the cache-first strategy.
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        // Cache hit - return response from cache.
        if (cachedResponse) {
          return cachedResponse;
        }

        // Not in cache, go to network.
        return fetch(event.request).then(
          networkResponse => {
            // Check if we received a valid response to cache.
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }

            // IMPORTANT: Clone the response. A response is a stream
            // and because we want the browser to consume the response
            // as well as the cache consuming the response, we need
            // to clone it so we have two streams.
            const responseToCache = networkResponse.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return networkResponse;
          }
        ).catch(error => {
            console.error('Service Worker fetch failed:', error);
            // If the network fails for a resource not in the cache, the request will fail.
            // This is acceptable for an online-first app.
        });
      })
  );
});


// Update a service worker and remove old caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim()) // Take control of open pages
  );
});