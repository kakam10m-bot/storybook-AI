
import React, { useState } from 'react';
import { MagicWandIcon } from './icons/MagicWandIcon';
import type { ThemeKey, DrawingStyle, FontKey, Difficulty, AspectRatioKey, Character, PdfLayoutKey } from '../types';
import { themesData } from '../themes';
import { drawingStylesData } from '../drawingStyles';
import { fontsData } from '../fonts';
import { difficultiesData } from '../difficulties';
import { aspectRatiosData } from '../aspectRatios';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { playSound } from '../services/audioService';
import { Tooltip } from './Tooltip';
import { InfoIcon } from './icons/InfoIcon';
import { SingleLayoutIcon, SplitLayoutIcon, BatchIcon } from './icons/LayoutIcons';
import { BookIcon } from './icons/BookIcon';
import { storySuggestionsData } from '../storySuggestions';
import { UserPlusIcon } from './icons/UserPlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PencilIcon } from './icons/PencilIcon';
import { CheckIcon } from './icons/CheckIcon';
import { XIcon } from './icons/XIcon';
import { pdfLayoutsData } from '../pdfLayouts';
import { PlayIcon } from './icons/PlaybackIcons';


interface InputFormProps {
  storyTitle: string;
  onStoryTitleChange: (title: string) => void;
  characterDescription: string;
  onCharacterDescriptionChange: (description: string) => void;
  characters: Character[];
  onCharactersChange: (characters: Character[]) => void;
  isAdultStory: boolean;
  onIsAdultStoryChange: (isAdult: boolean) => void;
  imagePrompts: { prompt1: string; prompt2: string };
  onImagePromptsChange: (prompts: { prompt1: string; prompt2: string }) => void;
  currentDescription: string;
  onCurrentDescriptionChange: (text: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  selectedTheme: ThemeKey;
  onThemeChange: (theme: ThemeKey) => void;
  selectedStyle: DrawingStyle;
  onStyleChange: (style: DrawingStyle) => void;
  customTextColor: string;
  onCustomTextColorChange: (color: string) => void;
  selectedFont: FontKey;
  onFontChange: (font: FontKey) => void;
  selectedDifficulty: Difficulty;
  onDifficultyChange: (difficulty: Difficulty) => void;
  selectedAspectRatio: AspectRatioKey;
  onAspectRatioChange: (aspectRatio: AspectRatioKey) => void;
  error: string | null;
  onSuggestText: () => void;
  isSuggestingText: boolean;
  scenesCount: number;
  sceneLayout: 'single' | 'split';
  onSceneLayoutChange: (layout: 'single' | 'split') => void;
  generationMode: 'single' | 'batch' | 'batch10';
  onGenerationModeChange: (mode: 'single' | 'batch' | 'batch10') => void;
  batchPrompt: string;
  onBatchPromptChange: (prompt: string) => void;
  disabled: boolean;
  writeTextOnImages: boolean;
  onWriteTextOnImagesChange: (write: boolean) => void;
  selectedPdfLayout: PdfLayoutKey;
  onPdfLayoutChange: (layout: PdfLayoutKey) => void;
  availableVoices: SpeechSynthesisVoice[];
  selectedVoiceURI: string | null;
  onSelectedVoiceURIChange: (uri: string) => void;
  onPreviewVoice: (uri: string) => void;
  isPreviewingVoice: boolean;
  lang: 'ar' | 'en';
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: any, options?: any) => string;
}

const getTranslatedData = (data: any, lang: 'ar' | 'en') => {
    const translated: any = {};
    for (const key in data) {
        translated[key] = {
            ...data[key],
            name: data[key].name[lang]
        }
    }
    return translated;
}

export const InputForm: React.FC<InputFormProps> = (props) => {
  const {
    storyTitle, onStoryTitleChange,
    characterDescription, onCharacterDescriptionChange,
    characters, onCharactersChange,
    isAdultStory, onIsAdultStoryChange,
    imagePrompts, onImagePromptsChange,
    currentDescription, onCurrentDescriptionChange,
    onSubmit, isLoading,
    selectedTheme, onThemeChange,
    selectedStyle, onStyleChange,
    customTextColor, onCustomTextColorChange,
    selectedFont, onFontChange,
    selectedDifficulty, onDifficultyChange,
    selectedAspectRatio, onAspectRatioChange,
    error, onSuggestText, isSuggestingText,
    scenesCount,
    sceneLayout, onSceneLayoutChange,
    generationMode, onGenerationModeChange,
    batchPrompt, onBatchPromptChange,
    disabled,
    writeTextOnImages, onWriteTextOnImagesChange,
    selectedPdfLayout, onPdfLayoutChange,
    availableVoices, selectedVoiceURI, onSelectedVoiceURIChange,
    onPreviewVoice,
    isPreviewingVoice,
    lang, t,
  } = props;
  
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [newCharacter, setNewCharacter] = useState({ name: '', description: '' });
  const [editingCharacter, setEditingCharacter] = useState<{ index: number; character: Character } | null>(null);

  const isFirstScene = scenesCount === 0;

  const isSplitLayout = sceneLayout === 'split';
  const canSubmit = storyTitle.trim() && (
    (generationMode === 'single' && currentDescription.trim() && imagePrompts.prompt1.trim() && (isSplitLayout ? imagePrompts.prompt2.trim() : true)) ||
    ((generationMode === 'batch' || generationMode === 'batch10') && batchPrompt.trim())
  );

  const isBatchMode = generationMode === 'batch' || generationMode === 'batch10';

  // Memoize translated data to prevent re-computation on every render
  const themes = React.useMemo(() => getTranslatedData(themesData, lang), [lang]);
  const drawingStyles = React.useMemo(() => getTranslatedData(drawingStylesData, lang), [lang]);
  const fonts = React.useMemo(() => getTranslatedData(fontsData, lang), [lang]);
  const difficulties = React.useMemo(() => getTranslatedData(difficultiesData, lang), [lang]);
  const aspectRatios = React.useMemo(() => getTranslatedData(aspectRatiosData, lang), [lang]);
  const pdfLayouts = React.useMemo(() => getTranslatedData(pdfLayoutsData, lang), [lang]);

  const textColors = React.useMemo(() => [
    { name: t('textColorDarkBrown'), value: '#4a2c2a' },
    { name: t('textColorNightBlue'), value: '#1e3a8a' },
    { name: t('textColorForestGreen'), value: '#14532d' },
    { name: t('textColorMaroon'), value: '#881337' },
    { name: t('textColorWhite'), value: '#ffffff' },
    { name: t('textColorBlack'), value: '#000000' },
  ], [t]);

  const sceneLayouts = React.useMemo(() => ({
    single: { name: t('sceneLayoutSingle'), Icon: SingleLayoutIcon },
    split: { name: t('sceneLayoutSplit'), Icon: SplitLayoutIcon },
  }), [t]);

  const generationModes = React.useMemo(() => ({
    single: { name: t('generationModeSingle'), Icon: SingleLayoutIcon },
    batch: { name: t('generationModeBatch5'), Icon: BatchIcon },
    batch10: { name: t('generationModeBatch10'), Icon: BatchIcon },
  }), [t]);

  const handleInspireMe = () => {
    playSound('suggest');
    const styleSuggestions = storySuggestionsData[selectedStyle][lang];
    let suggestion;
    if (styleSuggestions && styleSuggestions.length > 0) {
      suggestion = styleSuggestions[Math.floor(Math.random() * styleSuggestions.length)];
    } else {
      const allSuggestions = Object.values(storySuggestionsData).flatMap(s => s[lang]);
      if (allSuggestions.length > 0) {
        suggestion = allSuggestions[Math.floor(Math.random() * allSuggestions.length)];
      }
    }

    if (suggestion) {
      onStoryTitleChange(suggestion.title);
      onCharacterDescriptionChange(suggestion.characterDescription);
      onBatchPromptChange(suggestion.batchPrompt);
    }
  };

  const handleShowAdvanced = () => {
    playSound(showAdvanced ? 'close' : 'open');
    setShowAdvanced(!showAdvanced);
  }

  const handleAdultStoryChange = () => {
    playSound('click');
    onIsAdultStoryChange(!isAdultStory);
  };

  const handleFontChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    playSound('click');
    onFontChange(e.target.value as FontKey);
  };

  const handleTextColorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    playSound('click');
    onCustomTextColorChange(e.target.value);
  }

  const handleAddCharacter = () => {
    if (newCharacter.name.trim()) {
      const newCharacterWithId: Character = {
        id: `char-${Date.now()}`,
        name: newCharacter.name.trim(),
        description: newCharacter.description.trim(),
      };
      onCharactersChange([...characters, newCharacterWithId]);
      setNewCharacter({ name: '', description: '' });
      playSound('addScene');
    }
  };

  const handleRemoveCharacter = (id: string) => {
    onCharactersChange(characters.filter(c => c.id !== id));
    playSound('delete');
  };

  const handleStartEditing = (index: number, character: Character) => {
    setEditingCharacter({ index, character });
    playSound('click');
  };

  const handleSaveEdit = () => {
    if (editingCharacter && editingCharacter.character.name.trim()) {
      const updatedCharacters = [...characters];
      updatedCharacters[editingCharacter.index] = {
        ...editingCharacter.character,
        name: editingCharacter.character.name.trim(),
        description: editingCharacter.character.description.trim(),
      };
      onCharactersChange(updatedCharacters);
      setEditingCharacter(null);
      playSound('click');
    }
  };

  const handleCancelEdit = () => {
    setEditingCharacter(null);
    playSound('close');
  };
  
  const CharacterEditForm: React.FC<{
    character: { name: string, description: string };
    onCharacterChange: (char: { name: string, description: string }) => void;
    onSave: () => void;
    onCancel: () => void;
  }> = ({ character, onCharacterChange, onSave, onCancel }) => (
    <div className="flex flex-col gap-2 p-2">
      <input
        type="text"
        value={character.name}
        onChange={(e) => onCharacterChange({ ...character, name: e.target.value })}
        placeholder={t('charEditNamePlaceholder')}
        className="bg-stone-800 border border-stone-600 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition w-full"
        autoFocus
        onKeyDown={(e) => {
          if (e.key === 'Enter') onSave();
          if (e.key === 'Escape') onCancel();
        }}
      />
      <textarea
        value={character.description}
        onChange={(e) => onCharacterChange({ ...character, description: e.target.value })}
        placeholder={t('charEditDescPlaceholder')}
        className="bg-stone-800 border border-stone-600 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition w-full"
        rows={2}
        onKeyDown={(e) => {
            if (e.key === 'Enter' && e.metaKey) onSave();
            if (e.key === 'Escape') onCancel();
        }}
      />
      <div className="flex items-center gap-2 justify-end">
        <button onClick={onSave} className="p-1 text-green-400 hover:text-green-300 rounded-md hover:bg-stone-700" aria-label={t('saveAria')}>
          <CheckIcon className="w-5 h-5" />
        </button>
        <button onClick={onCancel} className="p-1 text-stone-400 hover:text-white rounded-md hover:bg-stone-700" aria-label={t('cancelAria')}>
          <XIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );

  const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="mb-4">
      <h3 className="text-lg font-semibold text-amber-400 mb-2">{title}</h3>
      {children}
    </div>
  );
  
  const RadioGrid: React.FC<{
    items: Record<string, { name: string; Icon: React.FC<{ className?: string }> }>;
    selectedValue: string;
    onChange: (value: string) => void;
    gridCols?: string;
    disabled?: boolean;
  }> = ({ items, selectedValue, onChange, gridCols = 'grid-cols-3', disabled = false }) => (
    <div className={`grid ${gridCols} gap-2`}>
      {Object.keys(items).map((key) => {
        const { name, Icon } = items[key];
        return (
        <button
          key={key}
          onClick={() => {
            if (selectedValue !== key && !disabled) {
              playSound('click');
              onChange(key);
            }
          }}
          disabled={disabled}
          className={`p-2 rounded-lg text-center transition-colors duration-200 border-2 ${
            selectedValue === key
              ? 'bg-amber-600 border-amber-400 text-white'
              : 'bg-stone-800/60 border-stone-700 hover:bg-stone-700/80 hover:border-stone-600'
          } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <Icon className="w-6 h-6 mx-auto mb-1" />
          <span className="text-xs font-medium">{name}</span>
        </button>
      )})}
    </div>
  );

  return (
    <div className="relative h-full">
       {disabled && (
            <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-md z-20 flex flex-col items-center justify-center text-center rounded-2xl p-4">
                <BookIcon className="w-16 h-16 text-amber-500 mb-4" />
                <h3 className="text-2xl font-bold text-stone-100 mb-2">{t('welcomeTitle')}</h3>
                <p className="text-stone-300">
                    {t('pleaseLogin')}
                </p>
            </div>
        )}
      <div className={`p-6 bg-stone-950/60 backdrop-blur-lg border border-amber-700/50 rounded-2xl shadow-lg h-full overflow-y-auto ${disabled ? 'blur-sm pointer-events-none' : ''}`}>
        <h2 className="text-2xl font-bold mb-6 text-stone-100">{t('controlPanel')}</h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="story-title" className="flex items-center text-sm font-medium text-stone-300 mb-1">
              {t('storyTitleLabel')} <span className="text-red-500 mx-1">*</span>
              <Tooltip text={t('storyTitleTooltip')}>
                  <InfoIcon className="w-4 h-4 text-stone-400 cursor-help" />
              </Tooltip>
            </label>
            <input
              type="text"
              id="story-title"
              value={storyTitle}
              onChange={(e) => onStoryTitleChange(e.target.value)}
              placeholder={t('storyTitlePlaceholder')}
              className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
            />
          </div>
          
          <div>
            <label htmlFor="character-description" className="flex items-center text-sm font-medium text-stone-300 mb-1">
              {t('mainCharLabel')}
              <Tooltip text={t('mainCharTooltip')}>
                  <InfoIcon className="w-4 h-4 ms-2 text-stone-400 cursor-help" />
              </Tooltip>
            </label>
            <textarea
              id="character-description"
              value={characterDescription}
              onChange={(e) => onCharacterDescriptionChange(e.target.value)}
              placeholder={t('mainCharPlaceholder')}
              className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
              rows={3}
            />
            <p className="mt-1 text-xs text-stone-400">
              {t('mainCharHint')}
            </p>
          </div>
          
          <div>
              <label className="flex items-center text-sm font-medium text-stone-300 mb-2">
                {t('additionalCharsLabel')}
                <Tooltip text={t('additionalCharsTooltip')}>
                    <InfoIcon className="w-4 h-4 ms-2 text-stone-400 cursor-help" />
                </Tooltip>
              </label>
              <div className="space-y-2">
                  {characters.map((char, index) => (
                    <div key={char.id} className="group bg-stone-900/50 rounded-lg border border-stone-700 transition-all duration-200 hover:border-stone-600">
                      {editingCharacter?.index === index ? (
                         <CharacterEditForm 
                           character={editingCharacter.character}
                           onCharacterChange={(updatedChar) => setEditingCharacter({ ...editingCharacter, character: {...editingCharacter.character, ...updatedChar} })}
                           onSave={handleSaveEdit}
                           onCancel={handleCancelEdit}
                         />
                      ) : (
                        <div className="flex items-start gap-3 p-3">
                          <div className="flex-grow">
                              <p className="font-semibold text-stone-100">{char.name}</p>
                              {char.description && <p className="text-sm text-stone-400 mt-1">{char.description}</p>}
                          </div>
                          <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex-shrink-0">
                            <button onClick={() => handleStartEditing(index, char)} className="p-1 text-stone-400 hover:text-amber-400 rounded-md hover:bg-stone-800/80" aria-label={t('editCharAria', { name: char.name })}>
                              <PencilIcon className="w-4 h-4" />
                            </button>
                            <button onClick={() => handleRemoveCharacter(char.id)} className="p-1 text-stone-400 hover:text-red-500 rounded-md hover:bg-stone-800/80" aria-label={t('removeCharAria', { name: char.name })}>
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
              <div className="flex flex-col items-start gap-2 mt-3 p-3 bg-stone-900/40 rounded-lg border border-stone-800">
                  <input
                    type="text"
                    value={newCharacter.name}
                    onChange={(e) => setNewCharacter({ ...newCharacter, name: e.target.value })}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddCharacter()}
                    placeholder={t('newCharNamePlaceholder')}
                    className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                  />
                   <textarea
                    value={newCharacter.description}
                    onChange={(e) => setNewCharacter({ ...newCharacter, description: e.target.value })}
                    placeholder={t('newCharDescPlaceholder')}
                    className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                    rows={2}
                  />
                  <button
                    onClick={handleAddCharacter}
                    disabled={!newCharacter.name.trim()}
                    className="flex-shrink-0 flex items-center justify-center bg-stone-700 text-amber-300 font-bold py-2 px-3 rounded-lg hover:bg-stone-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                    aria-label={t('addCharAria')}
                  >
                      <span>{t('addCharButton')}</span>
                      <UserPlusIcon className="w-5 h-5 ms-2" />
                  </button>
              </div>
          </div>
          
          <div className="flex items-center justify-between bg-stone-900/50 p-3 rounded-lg">
              <label htmlFor="adult-story-toggle" className="flex items-center text-sm font-medium text-stone-300">
                  {t('adultContentLabel')}
                  <Tooltip text={t('adultContentTooltip')}>
                      <InfoIcon className="w-4 h-4 ms-2 text-stone-400 cursor-help" />
                  </Tooltip>
              </label>
              <button
                  role="switch"
                  aria-checked={isAdultStory}
                  id="adult-story-toggle"
                  onClick={handleAdultStoryChange}
                  className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${isAdultStory ? 'bg-amber-600' : 'bg-stone-700'}`}
              >
                  <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isAdultStory ? 'translate-x-6 rtl:-translate-x-6' : 'translate-x-1 rtl:-translate-x-1'}`}/>
              </button>
          </div>
          
          <Section title={t('drawingStyleSection')}>
            <RadioGrid items={drawingStyles} selectedValue={selectedStyle} onChange={onStyleChange} gridCols="grid-cols-3" />
          </Section>
          
          <Section title={t('generationModeSection')}>
            <RadioGrid items={generationModes} selectedValue={generationMode} onChange={(v) => onGenerationModeChange(v as 'single' | 'batch' | 'batch10')} gridCols="grid-cols-3" />
          </Section>
          
          {generationMode === 'single' ? (
            <>
              <Section title={t('sceneLayoutSection')}>
                <RadioGrid items={sceneLayouts} selectedValue={sceneLayout} onChange={(v) => onSceneLayoutChange(v as 'single' | 'split')} gridCols="grid-cols-2" />
              </Section>

              <div>
                <label htmlFor="image-prompt-1" className="flex items-center text-sm font-medium text-stone-300 mb-1">
                      {isSplitLayout ? t('imagePrompt1SplitLabel') : t('imagePrompt1SingleLabel')} <span className="text-red-500 mx-1">*</span>
                      <Tooltip text={t('imagePromptTooltip')}>
                          <InfoIcon className="w-4 h-4 text-stone-400 cursor-help" />
                      </Tooltip>
                  </label>
                  <textarea
                      id="image-prompt-1"
                      value={imagePrompts.prompt1}
                      onChange={(e) => onImagePromptsChange({ ...imagePrompts, prompt1: e.target.value })}
                      placeholder={isSplitLayout ? t('imagePrompt1SplitPlaceholder') : t('imagePrompt1SinglePlaceholder')}
                      className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                      rows={isSplitLayout ? 2 : 3}
                  />
              </div>
              
              {isSplitLayout && (
                <div>
                    <label htmlFor="image-prompt-2" className="flex items-center text-sm font-medium text-stone-300 mb-1">
                          {t('imagePrompt2SplitLabel')} <span className="text-red-500 mx-1">*</span>
                      </label>
                      <textarea
                          id="image-prompt-2"
                          value={imagePrompts.prompt2}
                          onChange={(e) => onImagePromptsChange({ ...imagePrompts, prompt2: e.target.value })}
                          placeholder={t('imagePrompt2SplitPlaceholder')}
                          className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                          rows={2}
                      />
                  </div>
              )}

              <div>
                <label htmlFor="scene-text" className="flex items-center text-sm font-medium text-stone-300 mb-1">
                  {t('sceneTextLabel')} <span className="text-red-500 mx-1">*</span>
                  <Tooltip text={t('sceneTextTooltip')}>
                      <InfoIcon className="w-4 h-4 text-stone-400 cursor-help" />
                  </Tooltip>
                </label>
                <div className="relative">
                  <textarea
                    id="scene-text"
                    value={currentDescription}
                    onChange={(e) => onCurrentDescriptionChange(e.target.value)}
                    placeholder={t('sceneTextPlaceholder')}
                    className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 ps-28 focus:ring-amber-500 focus:border-amber-500 transition"
                    rows={5}
                  />
                  <button
                    onClick={onSuggestText}
                    disabled={isSuggestingText || !imagePrompts.prompt1}
                    className="absolute top-2 end-2 flex items-center bg-stone-700 text-amber-300 text-xs font-semibold py-1 px-2 rounded-md hover:bg-stone-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSuggestingText ? (
                      <div className="w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <span>{t('suggestTextButton')}</span>
                        <LightbulbIcon className="w-4 h-4 ms-1" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="batch-prompt" className="flex items-center text-sm font-medium text-stone-300">
                    {t('batchPromptLabel')} <span className="text-red-500 mx-1">*</span>
                    <Tooltip text={t('batchPromptTooltip')}>
                        <InfoIcon className="w-4 h-4 text-stone-400 cursor-help" />
                    </Tooltip>
                </label>
                <button
                    onClick={handleInspireMe}
                    className="flex items-center bg-stone-700 text-amber-300 text-xs font-semibold py-1 px-2 rounded-md hover:bg-stone-600 transition-colors"
                  >
                    <span>{t('inspireMeButton')}</span>
                    <LightbulbIcon className="w-4 h-4 ms-1" />
                </button>
              </div>
              <textarea
                  id="batch-prompt"
                  value={batchPrompt}
                  onChange={(e) => onBatchPromptChange(e.target.value)}
                  placeholder={t('batchPromptPlaceholder')}
                  className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                  rows={8}
              />
            </div>
          )}


          <button
            onClick={handleShowAdvanced}
            className="w-full text-sm text-amber-400 hover:text-amber-300"
          >
            {showAdvanced ? t('hideAdvancedButton') : t('showAdvancedButton')}
          </button>

          {showAdvanced && (
            <div className="space-y-6 pt-4 border-t border-stone-800">
              <Section title={t('aspectRatioSection')}>
                <RadioGrid items={aspectRatios} selectedValue={selectedAspectRatio} onChange={onAspectRatioChange} gridCols="grid-cols-5" disabled={!isFirstScene || isBatchMode} />
                {(!isFirstScene || isBatchMode) && (
                  <p className="mt-2 text-xs text-stone-400">
                    { isBatchMode ? t('aspectRatioBatchWarning', { count: generationMode === 'batch' ? 5 : 10 }) : t('aspectRatioSingleWarning') }
                  </p>
                )}
              </Section>
              <Section title={t('detailsLevelSection')}>
                <RadioGrid items={difficulties} selectedValue={selectedDifficulty} onChange={onDifficultyChange} />
              </Section>
              
              <Section title={t('pdfDesignSection')}>
                <div className="space-y-4 bg-stone-900/40 p-4 rounded-lg">
                  <div>
                      <h4 className="text-base font-medium text-stone-300 mb-2">{t('pdfLayoutLabel')}</h4>
                      <RadioGrid items={pdfLayouts} selectedValue={selectedPdfLayout} onChange={(v) => onPdfLayoutChange(v as PdfLayoutKey)} gridCols="grid-cols-3" />
                  </div>
                  <div>
                      <h4 className="text-base font-medium text-stone-300 mb-2">{t('pdfThemeLabel')}</h4>
                      <RadioGrid items={themes} selectedValue={selectedTheme} onChange={onThemeChange} gridCols="grid-cols-4"/>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="font-select" className="block text-sm font-medium text-stone-300 mb-1">
                          {t('fontLabel')}
                        </label>
                        <select
                          id="font-select"
                          value={selectedFont}
                          onChange={handleFontChange}
                          className="w-full bg-stone-800 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                        >
                          {/* FIX: Changed destructuring from `[key, { name }]` to `[key, value]` to avoid a type inference issue where value was considered `{}`. */}
                          {Object.entries(fonts).map(([key, value]) => (
                            <option key={key} value={key}>{(value as { name: string }).name}</option>
                          ))}
                        </select>
                    </div>
                    <div>
                      <label htmlFor="color-select" className="block text-sm font-medium text-stone-300 mb-1">
                          {t('textColorLabel')}
                        </label>
                        <select
                          id="color-select"
                          value={customTextColor}
                          onChange={handleTextColorChange}
                          className="w-full bg-stone-800 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                          style={{ backgroundColor: customTextColor, color: '#fff' }}
                        >
                          <option value={themes[selectedTheme].colors.text}>{t('defaultThemeColor')}</option>
                          {textColors.map(color => (
                              <option key={color.value} value={color.value} style={{ backgroundColor: color.value }}>
                                {color.name}
                              </option>
                            ))}
                        </select>
                    </div>
                  </div>
                </div>
              </Section>

              <Section title={t('narrationSection')}>
                <div className="bg-stone-900/40 p-4 rounded-lg">
                  <div>
                    <label htmlFor="voice-select" className="flex items-center text-sm font-medium text-stone-300 mb-1">
                      {t('narratorVoiceLabel')}
                       <Tooltip text={t('narratorVoiceTooltip')}>
                          <InfoIcon className="w-4 h-4 ms-2 text-stone-400 cursor-help" />
                      </Tooltip>
                    </label>
                    {availableVoices.length > 0 ? (
                      <div className="flex items-center gap-2">
                        <select
                          id="voice-select"
                          value={selectedVoiceURI || ''}
                          onChange={(e) => {
                            playSound('click');
                            onSelectedVoiceURIChange(e.target.value);
                          }}
                          className="flex-grow w-full bg-stone-800 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition"
                        >
                          <option value="">{t('browserDefaultVoice')}</option>
                          {availableVoices.map(voice => (
                              <option key={voice.voiceURI} value={voice.voiceURI}>
                                {voice.name} ({voice.lang})
                              </option>
                            ))}
                        </select>
                        <button
                          onClick={() => selectedVoiceURI && onPreviewVoice(selectedVoiceURI)}
                          disabled={!selectedVoiceURI || isPreviewingVoice}
                          className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-stone-700 text-amber-300 rounded-lg hover:bg-stone-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          aria-label={t('previewVoiceAria')}
                        >
                          {isPreviewingVoice ? (
                            <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                          ) : (
                            <PlayIcon className="w-5 h-5" />
                          )}
                        </button>
                      </div>
                    ) : (
                       <div className="w-full bg-stone-800 border border-stone-700 rounded-md p-2 text-stone-400 text-sm">
                        {t('noVoicesFound')}
                       </div>
                    )}
                    <p className="mt-2 text-xs text-stone-400">
                      {t('voicesDisclaimer')}
                      <br /><strong>{t('voicesTipLabel')}</strong> {t('voicesTip')}
                    </p>
                  </div>
                </div>
              </Section>

              <Section title={t('advancedImageOptionsSection')}>
                <div className="flex items-center justify-between bg-stone-900/50 p-3 rounded-lg">
                    <label htmlFor="write-text-toggle" className="flex items-center text-sm font-medium text-stone-300">
                        {t('writeOnImageLabel')}
                        <Tooltip text={t('writeOnImageTooltip')}>
                            <InfoIcon className="w-4 h-4 ms-2 text-stone-400 cursor-help" />
                        </Tooltip>
                    </label>
                    <button
                        role="switch"
                        aria-checked={writeTextOnImages}
                        id="write-text-toggle"
                        onClick={() => {
                            playSound('click');
                            onWriteTextOnImagesChange(!writeTextOnImages);
                        }}
                        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${writeTextOnImages ? 'bg-amber-600' : 'bg-stone-700'}`}
                    >
                        <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${writeTextOnImages ? 'translate-x-6 rtl:-translate-x-6' : 'translate-x-1 rtl:-translate-x-1'}`}/>
                    </button>
                </div>
              </Section>
            </div>
          )}

        </div>
        
        <div className="mt-6">
          {error && (
              <div className="bg-red-900/50 border border-red-700 text-red-200 p-3 rounded-lg text-sm animate-shake">
                  <p className="font-bold">{t('errorTitle')}</p>
                  <p>{error}</p>
              </div>
          )}
          <button
            onClick={onSubmit}
            disabled={!canSubmit || isLoading}
            className="w-full flex items-center justify-center bg-amber-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-amber-700 transition-all duration-300 disabled:bg-stone-500 disabled:cursor-not-allowed transform hover:scale-105 active:scale-100 focus:outline-none focus:ring-4 focus:ring-amber-300/50"
          >
            {isLoading ? (
              <div className="w-6 h-6 border-4 border-t-transparent border-white rounded-full animate-spin"></div>
            ) : (
              <>
                <MagicWandIcon className="w-5 h-5 me-2" />
                <span>
                  {generationMode === 'single'
                    ? t('addSceneButton')
                    : t('addScenesButton', { count: generationMode === 'batch' ? 5 : 10 })}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};