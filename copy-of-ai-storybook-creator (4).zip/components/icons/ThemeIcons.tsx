import React from 'react';

// Default: A simple open book
export const DefaultIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
  </svg>
);

// Playful: A kite
export const PlayfulIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 2L22 12 12 22 2 12z"></path>
    <path d="M12 2v20"></path>
    <path d="m19 19-7-7-7 7"></path>
  </svg>
);

// Adventure: Mountains
export const AdventureIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="m8 3 4 8 5-5 5 15H2L8 3z"></path>
  </svg>
);

// Dreamy: Cloud and stars
export const DreamyIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"></path>
    <path d="M22 10.5h.01"></path>
    <path d="M20 7h.01"></path>
  </svg>
);

// Mystery: Magnifying glass
export const MysteryIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="11" cy="11" r="8"></circle>
    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
  </svg>
);

// Nature: Leaf
export const NatureIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M11 20A7 7 0 0 1 4 13V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
    <path d="M15.5 8.5c.3-1 .5-2.2.5-3.5A2.5 2.5 0 0 0 13.5 3"></path>
  </svg>
);

// Ocean: Wave
export const OceanIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 12c.83-2 2.17-3 4-3s3.17 1 4 3 2.17 3 4 3 3.17-1 4-3"></path>
    <path d="M4 6c.83-2 2.17-3 4-3s3.17 1 4 3 2.17 3 4 3 3.17-1 4-3"></path>
    <path d="M4 18c.83-2 2.17-3 4-3s3.17 1 4 3 2.17 3 4 3 3.17-1 4-3"></path>
  </svg>
);

// Elegant: Diamond
export const ElegantIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2.7 10.3a2.4 2.4 0 0 0 0 3.4l7.5 7.5c.9.9 2.5.9 3.4 0l7.5-7.5a2.4 2.4 0 0 0 0-3.4l-7.5-7.5a2.4 2.4 0 0 0-3.4 0Z"></path>
    <path d="m12 22 4-4"></path>
    <path d="m10 10-5 5"></path>
    <path d="m14 14 5 5"></path>
    <path d="M12 2 8 6"></path>
  </svg>
);

// Scifi: Rocket
export const ScifiIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.3.05-3.12-1.2-1.6-2.6-2.8-4.05-3.12-1.45-.3-2.6.5-3.1 1.25z"></path>
    <path d="m12 2 7 7-7 7-7-7Z"></path>
    <path d="m8 16 1.5-1.5"></path>
    <path d="M13 21v-2"></path>
    <path d="M16 8 14.5 9.5"></path>
    <path d="M21 11h-2"></path>
  </svg>
);

// Horror: Ghost
export const HorrorIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
    <path d="M12 11a4 4 0 0 1 0-8h.01"></path>
    <path d="M12 11a4 4 0 0 0 0-8h-.01"></path>
    <circle cx="10" cy="11" r="1"></circle>
    <circle cx="14" cy="11" r="1"></circle>
  </svg>
);

// FairyTale: Castle
export const FairyTaleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M19 13v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path>
    <path d="M3 13h18"></path>
    <path d="M12 21V9"></path>
    <path d="M12 9l5-4 1-4H6l1 4Z"></path>
  </svg>
);

// Western: Cactus
export const WesternIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M18 9v11a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V9"></path>
    <path d="M6 9H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h2"></path>
    <path d="M18 9h2a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-2"></path>
    <path d="M12 22V9"></path>
  </svg>
);

// Cosmic: Saturn
export const CosmicIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="6"></circle>
    <path d="M19.07 4.93a10 10 0 0 0-14.14 14.14"></path>
    <path d="M4.93 4.93a10 10 0 0 1 14.14 0"></path>
  </svg>
);