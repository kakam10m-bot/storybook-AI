
import React from 'react';

// Classic Layout: Image top, text bottom
export const ClassicLayoutIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <rect x="6" y="6" width="12" height="8" />
    <line x1="6" y1="17" x2="18" y2="17" />
    <line x1="6" y1="19" x2="14" y2="19" />
  </svg>
);

// Full Bleed Layout: Image as background
export const FullBleedLayoutIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <path d="M3 12l3-3 4 4 5-5 6 6" />
    <line x1="6" y1="17" x2="18" y2="17" />
    <line x1="6" y1="19" x2="14" y2="19" />
  </svg>
);

// Side by Side Layout: Image left, text right
export const SideBySideLayoutIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
    <line x1="12" y1="3" x2="12" y2="21" />
    <rect x="5" y="7" width="5" height="10" />
    <line x1="14" y1="8" x2="19" y2="8" />
    <line x1="14" y1="12" x2="19" y2="12" />
    <line x1="14" y1="16" x2="19" y2="16" />
  </svg>
);
