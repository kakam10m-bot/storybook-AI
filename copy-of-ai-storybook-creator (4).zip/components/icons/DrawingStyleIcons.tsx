import React from 'react';

// Storybook Icon (A whimsical open book with stars)
export const StorybookIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
    <path d="M12 6.5l.5 1 .5-1 .5 1 .5-1"/>
    <path d="M15 4.5l.5 1 .5-1"/>
  </svg>
);

// Realistic Icon (A camera lens/aperture)
export const RealisticIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10"></circle>
    <circle cx="12" cy="12" r="3"></circle>
    <line x1="12" y1="2" x2="12" y2="4"></line>
    <line x1="12" y1="20" x2="12" y2="22"></line>
    <line x1="2" y1="12" x2="4" y2="12"></line>
    <line x1="20" y1="12" x2="22" y2="12"></line>
  </svg>
);

// Anime Icon (A stylized anime eye)
export const AnimeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"></path>
    <circle cx="12" cy="12" r="4"></circle>
    <path d="M14 10.5c.5.5.5 1 0 1.5s-1 .5-1.5 0"></path>
  </svg>
);

// Cartoon Icon (A classic cartoon glove)
export const CartoonIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M18 13V9a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v4.5c0 1.1.9 2 2 2h2.5c.8 0 1.5.7 1.5 1.5v.5c0 .8-.7 1.5-1.5 1.5h-1a2 2 0 0 0-2 2v1h8v-1a2 2 0 0 0-2-2h-1a1.5 1.5 0 0 1-1.5-1.5v-.5c0-.8.7-1.5 1.5-1.5H16a2 2 0 0 0 2-2z"></path>
    <path d="M8 8V7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1"></path>
  </svg>
);

// Fantasy Icon (A sword)
export const FantasyIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M14.5 17.5L3 6V3h3l11.5 11.5"></path>
    <path d="M13 19l6-6"></path>
    <path d="M16 16l4 4"></path>
    <path d="M19 13l-1.5 1.5"></path>
  </svg>
);

// Noir Icon (A fedora hat)
export const NoirIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 14c-3.87 0-7-1.34-7-3V9c0-1.66 3.13-3 7-3s7 1.34 7 3v2c0 1.66-3.13 3-7 3z"></path>
    <path d="M19 11v2c0 1.66-3.13 3-7 3s-7-1.34-7-3v-2"></path>
    <path d="M5 14v1a7 7 0 0 0 14 0v-1"></path>
  </svg>
);

// Vintage Icon (An old film camera)
export const VintageIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="2" y="7" width="20" height="12" rx="2" ry="2"></rect>
    <circle cx="7" cy="13" r="2"></circle>
    <circle cx="17" cy="13" r="2"></circle>
    <line x1="7" y1="7" x2="7" y2="5"></line>
    <line x1="17" y1="7" x2="17" y2="5"></line>
  </svg>
);

// Minimalist Icon (A simple arc)
export const MinimalistIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M3 12c0-5 4-9 9-9s9 4 9 9-4 9-9 9"></path>
    </svg>
);

// Cinematic Icon (A film reel)
export const CinematicIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect>
    <line x1="7" y1="2" x2="7" y2="22"></line>
    <line x1="17" y1="2" x2="17" y2="22"></line>
    <line x1="2" y1="12" x2="22" y2="12"></line>
    <line x1="2" y1="7" x2="7" y2="7"></line>
    <line x1="2" y1="17" x2="7" y2="17"></line>
    <line x1="17" y1="17" x2="22" y2="17"></line>
    <line x1="17" y1="7" x2="22" y2="7"></line>
  </svg>
);

// Digital Art Icon (Artist's Palette)
export const DigitalArtIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M15.003 3.84A9.955 9.955 0 0 0 12 3c-5.523 0-10 4.477-10 10 0 2.44.872 4.683 2.343 6.452" />
    <path d="M21 12c0-2.44-.872-4.683-2.343-6.452A9.955 9.955 0 0 0 12 3a10 10 0 0 0-7 17.66" />
    <path d="M18.32 14.89a2 2 0 1 1-2.828-2.828 2 2 0 0 1 2.828 2.828z" />
    <path d="M12.5 7.5a2 2 0 1 1-2.828-2.828 2 2 0 0 1 2.828 2.828z" />
    <path d="M7 13a2 2 0 1 1-2.828-2.828 2 2 0 0 1 2.828 2.828z" />
  </svg>
);
