import React from 'react';

// Easy Icon (One star)
export const EasyIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
  </svg>
);

// Medium Icon (Two stars)
export const MediumIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <polygon points="7 8 8.69 11.3 12.4 11.81 9.7 14.43 10.37 18.12 7 16.25 3.63 18.12 4.3 14.43 1.6 11.81 5.31 11.3 7 8"/>
        <polygon points="17 8 18.69 11.3 22.4 11.81 19.7 14.43 20.37 18.12 17 16.25 13.63 18.12 14.3 14.43 11.6 11.81 15.31 11.3 17 8"/>
    </svg>
);

// Hard Icon (Three stars)
export const HardIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <polygon points="12 3 13.69 6.3 17.4 6.81 14.7 9.43 15.37 13.12 12 11.25 8.63 13.12 9.3 9.43 6.6 6.81 10.31 6.3 12 3"/>
        <polygon points="7 13 8.69 16.3 12.4 16.81 9.7 19.43 10.37 23.12 7 21.25 3.63 23.12 4.3 19.43 1.6 16.81 5.31 16.3 7 13"/>
        <polygon points="17 13 18.69 16.3 22.4 16.81 19.7 19.43 20.37 23.12 17 21.25 13.63 23.12 14.3 19.43 11.6 16.81 15.31 16.3 17 13"/>
    </svg>
);
