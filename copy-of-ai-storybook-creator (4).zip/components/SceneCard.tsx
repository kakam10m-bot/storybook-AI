import React, { useRef, useEffect } from 'react';
import type { Scene } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { ExpandIcon } from './icons/ExpandIcon';

interface SceneCardProps {
  scene: Scene;
  sceneNumber: number;
  onDelete: (id: string) => void;
  onPreview: (scene: Scene) => void;
  isCurrentlyNarrating: boolean;
}

export const SceneCard: React.FC<SceneCardProps> = ({ scene, sceneNumber, onDelete, onPreview, isCurrentlyNarrating }) => {
  const hasMultipleImages = scene.imageUrls && scene.imageUrls.length > 1;
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isCurrentlyNarrating && cardRef.current) {
      cardRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [isCurrentlyNarrating]);

  const narratingClasses = isCurrentlyNarrating
    ? 'ring-4 ring-amber-400 ring-offset-2 ring-offset-stone-900 shadow-lg shadow-amber-500/50'
    : '';

  return (
    <div
      ref={cardRef}
      className={`relative group rounded-xl shadow-lg overflow-hidden transform hover:scale-[1.02] hover:shadow-xl transition-all duration-300 h-64 animate-fadeInScene ${narratingClasses}`}>
      <div className="absolute inset-0 cursor-pointer z-10" onClick={() => onPreview(scene)} aria-label={`Preview scene ${sceneNumber}`}></div>
      
      {hasMultipleImages ? (
        <div className="flex w-full h-full">
          <img src={scene.imageUrls[0]} alt={`Scene ${sceneNumber}, part 1`} className="w-1/2 h-full object-cover" />
          <div className="w-px bg-stone-700"></div>
          <img src={scene.imageUrls[1]} alt={`Scene ${sceneNumber}, part 2`} className="w-1/2 h-full object-cover" />
        </div>
      ) : (
        <img src={scene.imageUrls[0]} alt={`Scene ${sceneNumber}`} className="w-full h-full object-cover" />
      )}

      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none"></div>
      
      <div className="absolute top-2 right-2 bg-amber-700 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg shadow-md z-10 pointer-events-none">
        {sceneNumber}
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
        <ExpandIcon className="w-16 h-16 text-white/80" />
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation();
          onDelete(scene.id);
        }}
        aria-label={`Delete scene ${sceneNumber}`}
        className="absolute top-2 left-2 bg-red-600 text-white w-10 h-10 rounded-full flex items-center justify-center shadow-md z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
      >
        <TrashIcon className="w-5 h-5" />
      </button>

      <div className="absolute bottom-0 left-0 right-0 p-6 pointer-events-none">
        <p className="text-white leading-relaxed max-h-24 overflow-y-auto">{scene.description}</p>
      </div>
    </div>
  );
};
