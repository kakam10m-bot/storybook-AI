import React, { useState } from 'react';
import { BookIcon } from './icons/BookIcon';
import { playSound } from '../services/audioService';
import { registerUser, loginUser } from '../services/authService';
import { UserIcon } from './icons/UserIcon';
import { LockIcon } from './icons/LockIcon';


interface LoginScreenProps {
  onLoginSuccess: (userId: string) => void;
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: any, options?: any) => string;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess, t }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const isAdminLogin = username.trim().toLowerCase() === 'kakam10m';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || !username.trim() || !password.trim()) return;

    setIsLoading(true);
    setError('');

    try {
      if (mode === 'register' && !isAdminLogin) {
        const newUser = await registerUser(username, password, t);
        playSound('addScene');
        onLoginSuccess(newUser.username);
      } else {
        const user = await loginUser(username, password, t);
        playSound('addScene');
        onLoginSuccess(user.username);
      }
    } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError(t('errorUnknown'));
        }
        playSound('error');
        setUsername('');
        setPassword('');
    } finally {
        setIsLoading(false);
    }
  };

  const toggleMode = () => {
    setError('');
    setUsername('');
    setPassword('');
    setMode(prevMode => (prevMode === 'login' ? 'register' : 'login'));
    playSound('click');
  }

  return (
    <div className="fixed inset-0 bg-stone-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-stone-900/70 border border-amber-700/50 rounded-2xl shadow-2xl p-8 text-center animate-slideUp">
        <BookIcon className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        
        <h2 className="text-3xl font-bold text-stone-100 mb-2">
            {isAdminLogin ? t('adminLogin') : (mode === 'login' ? t('welcomeBack') : t('createAccount'))}
        </h2>
        <p className="text-stone-300 mb-6">
            {isAdminLogin
              ? t('adminPrompt')
              : mode === 'login'
              ? t('loginPrompt')
              : t('registerPrompt')}
        </p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
                <UserIcon className="w-5 h-5 text-stone-400 absolute top-1/2 end-3 transform -translate-y-1/2" />
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={t('usernamePlaceholder')}
                  className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-3 pe-10 text-lg focus:ring-amber-500 focus:border-amber-500 transition"
                  required
                  autoFocus
                />
            </div>
             <div className="relative">
                <LockIcon className="w-5 h-5 text-stone-400 absolute top-1/2 end-3 transform -translate-y-1/2" />
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={isAdminLogin ? t('adminPasswordPlaceholder') : t('passwordPlaceholder')}
                  className="w-full bg-stone-950/80 border border-stone-700 rounded-md p-3 pe-10 text-lg focus:ring-amber-500 focus:border-amber-500 transition"
                  required
                />
            </div>
          
          {error && <p className="text-red-400 text-sm animate-shake">{error}</p>}
          
          <button
            type="submit"
            disabled={isLoading || !username || !password}
            className="w-full flex items-center justify-center bg-amber-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-amber-700 transition-all duration-300 disabled:bg-stone-500 disabled:cursor-not-allowed transform hover:scale-105 active:scale-100 focus:outline-none focus:ring-4 focus:ring-amber-300/50"
          >
            {isLoading ? (
              <div className="w-6 h-6 border-4 border-t-transparent border-white rounded-full animate-spin"></div>
            ) : (
              <span>{mode === 'login' || isAdminLogin ? t('loginButton') : t('createAccountButton')}</span>
            )}
          </button>
        </form>

        {!isAdminLogin && (
          <div className="mt-6">
              <button onClick={toggleMode} className="text-sm text-amber-400 hover:text-amber-300 hover:underline">
                  {mode === 'login' ? t('noAccountPrompt') : t('hasAccountPrompt')}
              </button>
          </div>
        )}
      </div>
       <style>{`
        @keyframes slideUp {
          from { transform: translateY(20px) scale(0.98); opacity: 0; }
          to { transform: translateY(0) scale(1); opacity: 1; }
        }
        .animate-slideUp { animation: slideUp 0.4s ease-out forwards; }
      `}</style>
    </div>
  );
};