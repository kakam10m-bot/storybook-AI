import React from 'react';

export const Loader: React.FC<{ message: string }> = ({ message }) => {
  return (
    <div className="absolute inset-0 bg-stone-950/70 backdrop-blur-sm flex flex-col items-center justify-center z-50 rounded-lg">
      <div className="w-16 h-16 border-4 border-t-transparent border-amber-500 rounded-full animate-spin"></div>
      <p className="mt-4 text-stone-100 text-lg font-semibold">{message}</p>
    </div>
  );
};