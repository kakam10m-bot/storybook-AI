import React from 'react';
import type { StoryData } from '../types';
import { BookIcon } from './icons/BookIcon';
import { playSound } from '../services/audioService';
import { TrashIcon } from './icons/TrashIcon';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: StoryData[];
  onLoadStory: (story: StoryData) => void;
  onDeleteStory: (storyId: string) => void;
  t: (key: any, options?: any) => string;
  lang: 'ar' | 'en';
}

export const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose, history, onLoadStory, onDeleteStory, t, lang }) => {
  if (!isOpen) return null;

  const handleClose = () => {
    playSound('close');
    onClose();
  }
  
  const handleDelete = (storyId: string, storyTitle: string) => {
    const confirmation = window.confirm(t('deleteStoryConfirm', { title: storyTitle || t('untitledStory') }));
    if (confirmation) {
      onDeleteStory(storyId);
    }
  }


  return (
    <div
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300 animate-fadeIn"
      onClick={handleClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-stone-900 border border-amber-800/50 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden m-4 transform transition-all duration-300 animate-slideUp"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-stone-700">
          <h3 className="text-xl font-bold text-amber-400">{t('historyTitle')}</h3>
          <button
            onClick={handleClose}
            aria-label={t('closeHistoryAria')}
            className="text-stone-400 hover:text-white transition-colors p-2 rounded-full hover:bg-stone-700"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        <div className="flex-grow p-6 overflow-y-auto">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center text-stone-400 h-full">
                <BookIcon className="w-16 h-16 text-stone-500 mb-4" />
                <h3 className="text-xl font-semibold text-stone-300">{t('noHistoryTitle')}</h3>
                <p className="mt-2">{t('noHistorySubtitle')}</p>
            </div>
          ) : (
            <ul className="space-y-4">
              {history.map((story) => (
                <li key={story.id} className="bg-stone-800/50 p-4 rounded-lg flex items-center gap-4 border border-stone-700 hover:border-amber-600/50 transition-colors">
                    <div className="w-20 h-24 bg-stone-700 rounded-md flex-shrink-0 overflow-hidden flex items-center justify-center">
                        {story.coverImageUrl ? (
                            <img src={story.coverImageUrl} alt={t('coverAlt', { title: story.storyTitle })} className="w-full h-full object-cover" />
                        ) : (
                            <BookIcon className="w-8 h-8 text-stone-500" />
                        )}
                    </div>
                  <div className="flex-grow">
                    <h4 className="font-bold text-lg text-stone-100">{story.storyTitle || t('untitledStory')}</h4>
                    <p className="text-sm text-stone-400">
                      {t('lastUpdated')}: {new Date(story.lastModified).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}
                    </p>
                     <p className="text-xs text-stone-500 mt-1">
                      {story.scenes.length} {t('scenesCount', { count: story.scenes.length })}
                    </p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => onLoadStory(story)}
                      className="bg-amber-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-amber-700 transition-colors"
                    >
                      {t('loadButton')}
                    </button>
                    <button
                      onClick={() => handleDelete(story.id, story.storyTitle)}
                      className="bg-red-800/70 text-red-200 font-semibold py-2 px-4 rounded-md hover:bg-red-700/80 transition-colors flex items-center justify-center gap-2"
                      aria-label={t('deleteStoryAria', { title: story.storyTitle || t('untitledStory') })}
                    >
                      <TrashIcon className="w-4 h-4" />
                      {t('deleteButton')}
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
       <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slideUp {
          from { transform: translateY(20px) scale(0.98); opacity: 0; }
          to { transform: translateY(0) scale(1); opacity: 1; }
        }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
        .animate-slideUp { animation: slideUp 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};