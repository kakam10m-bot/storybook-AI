import React, { useState, useEffect } from 'react';
import type { Scene } from '../types';
import { ThumbsUpIcon, ThumbsDownIcon } from './icons/FeedbackIcons';

interface PreviewModalProps {
  scene: Scene | null;
  onClose: () => void;
  onFeedbackSubmit: (sceneId: string, rating: 'up' | 'down' | null, comment: string) => void;
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: any, options?: any) => string;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({ scene, onClose, onFeedbackSubmit, t }) => {
  if (!scene) return null;

  const [rating, setRating] = useState<'up' | 'down' | null>(scene.feedback?.rating ?? null);
  const [comment, setComment] = useState(scene.feedback?.comment ?? '');

  // Effect to reset local state when the scene prop changes
  useEffect(() => {
    setRating(scene.feedback?.rating ?? null);
    setComment(scene.feedback?.comment ?? '');
  }, [scene]);

  const handleRating = (newRating: 'up' | 'down') => {
    const finalRating = rating === newRating ? null : newRating;
    setRating(finalRating);
    onFeedbackSubmit(scene.id, finalRating, comment);
  };
  
  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setComment(e.target.value);
      onFeedbackSubmit(scene.id, rating, e.target.value);
  }

  const hasMultipleImages = scene.imageUrls && scene.imageUrls.length > 1;

  return (
    <div
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300 animate-fadeIn"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-stone-900 border border-amber-800/50 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden m-4 transform transition-all duration-300 animate-slideUp"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-stone-700">
          <h3 className="text-xl font-bold text-amber-400">{t('scenePreviewTitle')}</h3>
          <button
            onClick={onClose}
            aria-label={t('closePreviewAria')}
            className="text-stone-400 hover:text-white transition-colors p-2 rounded-full hover:bg-stone-700"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        <div className="flex-grow p-6 overflow-y-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
            <div className="flex items-center justify-center bg-stone-950 rounded-lg overflow-hidden">
              {hasMultipleImages ? (
                <div className="flex w-full h-full gap-2">
                  <img src={scene.imageUrls[0]} alt={t('scenePreviewAlt1')} className="max-h-[60vh] w-1/2 h-auto object-contain" />
                  <img src={scene.imageUrls[1]} alt={t('scenePreviewAlt2')} className="max-h-[60vh] w-1/2 h-auto object-contain" />
                </div>
              ) : (
                <img src={scene.imageUrls[0]} alt={t('scenePreviewAlt')} className="max-h-[60vh] w-auto h-auto object-contain" />
              )}
            </div>
            <div className="text-stone-200 flex flex-col">
              <div className="flex-grow">
                <h4 className="text-lg font-semibold text-stone-300 mb-4 border-b border-stone-700 pb-2">{t('scenePreviewTextLabel')}</h4>
                <p className="leading-relaxed text-lg" style={{ whiteSpace: 'pre-wrap' }}>{scene.description}</p>
              </div>

              <div className="mt-auto pt-4 border-t border-stone-800">
                <h4 className="text-lg font-semibold text-stone-300 mb-3">{t('scenePreviewFeedbackLabel')}</h4>
                <div className="flex items-start gap-4">
                  <div className="flex gap-2">
                        <button
                          onClick={() => handleRating('up')}
                          aria-label={t('scenePreviewGoodAria')}
                          className={`p-3 rounded-full transition-colors duration-200 border-2 ${rating === 'up' ? 'bg-green-500/20 border-green-500 text-green-400' : 'bg-stone-800 border-stone-700 text-stone-400 hover:bg-stone-700 hover:border-green-600'}`}
                      >
                          <ThumbsUpIcon className="w-6 h-6" />
                      </button>
                      <button
                          onClick={() => handleRating('down')}
                          aria-label={t('scenePreviewBadAria')}
                          className={`p-3 rounded-full transition-colors duration-200 border-2 ${rating === 'down' ? 'bg-red-500/20 border-red-500 text-red-400' : 'bg-stone-800 border-stone-700 text-stone-400 hover:bg-stone-700 hover:border-red-600'}`}
                      >
                          <ThumbsDownIcon className="w-6 h-6" />
                      </button>
                  </div>
                  <textarea
                      value={comment}
                      onChange={handleCommentChange}
                      placeholder={t('scenePreviewFeedbackPlaceholder')}
                      className="flex-grow bg-stone-950/80 border border-stone-700 rounded-md p-2 focus:ring-amber-500 focus:border-amber-500 transition text-sm"
                      rows={3}
                  />
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
       <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slideUp {
          from { transform: translateY(20px) scale(0.98); opacity: 0; }
          to { transform: translateY(0) scale(1); opacity: 1; }
        }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
        .animate-slideUp { animation: slideUp 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};