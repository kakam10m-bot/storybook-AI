import React from 'react';
import { BookIcon } from './icons/BookIcon';

interface CoverCardProps {
  imageUrl: string;
  title: string;
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: any, options?: any) => string;
}

export const CoverCard: React.FC<CoverCardProps> = ({ imageUrl, title, t }) => {
  return (
    <div className="md:col-span-2 relative group rounded-xl shadow-lg overflow-hidden transform hover:scale-[1.01] hover:shadow-xl transition-all duration-300 h-80 animate-fadeInScene border-2 border-amber-400/50">
      <img src={imageUrl} alt={t('coverAlt', { title })} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent pointer-events-none"></div>
      
      <div className="absolute top-2 end-2 bg-amber-600 text-white px-3 py-1 rounded-full flex items-center justify-center font-bold text-sm shadow-md z-10 pointer-events-none">
        <BookIcon className="w-4 h-4 me-2" />
        <span>{t('coverLabel')}</span>
      </div>
      
      <div className="absolute bottom-0 start-0 end-0 p-6 pointer-events-none z-10">
        <h3 className="text-white text-3xl font-bold" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.7)' }}>{title}</h3>
      </div>
    </div>
  );
};