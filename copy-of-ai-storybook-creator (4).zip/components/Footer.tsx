import React from 'react';
import { BookIcon } from './icons/BookIcon';

interface FooterProps {
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: string, options?: any) => string;
}

export const Footer: React.FC<FooterProps> = ({ t }) => {
  return (
    <footer className="mt-12 py-8 px-4 sm:px-8 bg-stone-950/40 border-t border-amber-800/30 backdrop-blur-sm">
      <div className="container mx-auto text-center text-stone-400">
        <div className="flex justify-center items-center mb-4">
            <BookIcon className="w-6 h-6 text-amber-500" />
            <h3 className="text-xl font-bold text-stone-200 mx-3">{t('aboutTitle')}</h3>
        </div>
        <p className="max-w-3xl mx-auto leading-relaxed text-stone-300">
            {t('aboutParagraph')}
        </p>
        <div className="mt-6 text-sm text-stone-500">
            <p>&copy; {new Date().getFullYear()} {t('appTitle')}. {t('copyright')}</p>
        </div>
      </div>
    </footer>
  );
};