import React from 'react';
import type { Scene } from '../types';
import { SceneCard } from './SceneCard';
import { PdfIcon } from './icons/PdfIcon';
import { Loader } from './Loader';
import { QuillIcon } from './icons/QuillIcon';
import { CoverCard } from './CoverCard';
import { BookIcon } from './icons/BookIcon';
import { SocialShare } from './SocialShare';
import { ImageIcon } from './icons/ImageIcon';
import { PlayIcon, PauseIcon, StopIcon } from './icons/PlaybackIcons';


interface StoryPreviewProps {
  scenes: Scene[];
  onExport: () => void;
  isLoading: boolean;
  loadingMessage: string;
  isExportingPdf: boolean;
  storyTitle: string;
  coverImageUrl: string | null;
  onDeleteScene: (id: string) => void;
  onPreviewScene: (scene: Scene) => void;
  disabled: boolean;
  onGenerateCover: () => void;
  isGeneratingCover: boolean;
  isNarrating: boolean;
  isNarrationPaused: boolean;
  narratingSceneId: string | null;
  onPlayStory: () => void;
  onPauseStory: () => void;
  onStopStory: () => void;
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: any, options?: any) => string;
}

export const StoryPreview: React.FC<StoryPreviewProps> = ({ 
  scenes, 
  onExport, 
  isLoading, 
  loadingMessage, 
  isExportingPdf, 
  storyTitle, 
  coverImageUrl, 
  onDeleteScene, 
  onPreviewScene, 
  disabled, 
  onGenerateCover, 
  isGeneratingCover,
  isNarrating,
  isNarrationPaused,
  narratingSceneId,
  onPlayStory,
  onPauseStory,
  onStopStory,
  t
 }) => {
  return (
    <div className="relative h-full">
      {disabled && (
        <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-md z-20 flex flex-col items-center justify-center text-center rounded-2xl p-4">
            <BookIcon className="w-16 h-16 text-amber-500 mb-4" />
            <h3 className="text-2xl font-bold text-stone-100 mb-2">{t('previewTitle')}</h3>
            <p className="text-stone-300">
              {t('previewLoginPrompt')}
            </p>
        </div>
      )}
      <div className={`p-6 bg-stone-950/60 backdrop-blur-lg border border-amber-700/50 rounded-2xl shadow-lg h-full flex flex-col relative ${disabled ? 'blur-sm pointer-events-none' : ''}`}>
        <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
          <h2 className="text-2xl font-bold text-stone-100">{t('previewTitle')}</h2>
          {scenes.length > 0 && (
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2 p-1 bg-stone-800/50 rounded-lg border border-stone-700">
                {!isNarrating ? (
                  <button onClick={onPlayStory} className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-3 rounded-md transition-colors" aria-label={t('listenAria')}>
                    <PlayIcon className="w-5 h-5" />
                    <span>{t('listenButton')}</span>
                  </button>
                ) : (
                  <>
                    <button onClick={isNarrationPaused ? onPlayStory : onPauseStory} className="bg-amber-600 hover:bg-amber-700 text-white p-2 rounded-md transition-colors" aria-label={isNarrationPaused ? t('resumeAria') : t('pauseAria')}>
                      {isNarrationPaused ? <PlayIcon className="w-5 h-5" /> : <PauseIcon className="w-5 h-5" />}
                    </button>
                    <button onClick={onStopStory} className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-md transition-colors" aria-label={t('stopAria')}>
                      <StopIcon className="w-5 h-5" />
                    </button>
                  </>
                )}
              </div>
               <SocialShare storyTitle={storyTitle} t={t} />
               <button
                onClick={onGenerateCover}
                disabled={isLoading || isGeneratingCover || isExportingPdf || scenes.length === 0}
                className="flex items-center justify-center bg-stone-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-stone-600 transition-colors duration-300 disabled:bg-stone-500/50 disabled:cursor-not-allowed transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-amber-300/50"
              >
                {isGeneratingCover ? (
                  <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <ImageIcon className="w-5 h-5 me-2" />
                    <span>{t('newCoverButton')}</span>
                  </>
                )}
              </button>
              <button
                onClick={onExport}
                disabled={isLoading || isExportingPdf || isGeneratingCover}
                className="flex items-center justify-center bg-amber-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors duration-300 disabled:bg-stone-500 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-amber-300/50"
              >
                {isExportingPdf ? (
                  <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <PdfIcon className="w-5 h-5 me-2" />
                    <span>{t('exportPdfButton')}</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        <div className="flex-grow overflow-y-auto pe-4 -me-4">
          {scenes.length === 0 && !isLoading && (
            <div className="h-full flex flex-col items-center justify-center text-center text-stone-400">
              <QuillIcon className="w-16 h-16 text-stone-500 mb-4" />
              <h3 className="text-xl font-semibold text-stone-300">{t('emptyPreviewTitle')}</h3>
              <p className="mt-2 max-w-sm">
                {t('emptyPreviewSubtitle')}
              </p>
            </div>
          )}

          {(scenes.length > 0 || isLoading) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {coverImageUrl && <CoverCard imageUrl={coverImageUrl} title={storyTitle} t={t} />}
              {scenes.map((scene, index) => (
                <SceneCard 
                  key={scene.id} 
                  scene={scene} 
                  sceneNumber={index + 1} 
                  onDelete={onDeleteScene} 
                  onPreview={onPreviewScene} 
                  isCurrentlyNarrating={scene.id === narratingSceneId}
                />
              ))}
            </div>
          )}
        </div>
        {isLoading && <Loader message={loadingMessage} />}
        {isExportingPdf && <Loader message={t('pdfExportingMessage')} />}
      </div>
    </div>
  );
};