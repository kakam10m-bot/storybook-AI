import React from 'react';
import { MagicWandIcon } from './icons/MagicWandIcon';
import { BookIcon } from './icons/BookIcon';
import { playSound } from '../services/audioService';

interface MobileNavProps {
  activeTab: 'form' | 'preview';
  setActiveTab: (tab: 'form' | 'preview') => void;
  scenesCount: number;
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: string, options?: any) => string;
}

const NavButton: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
  badgeCount?: number;
}> = ({ label, icon, isActive, onClick, badgeCount }) => (
  <button
    onClick={onClick}
    className={`flex-1 flex flex-col items-center justify-center p-2 transition-colors duration-200 relative ${
      isActive ? 'text-amber-400' : 'text-stone-400 hover:text-stone-200'
    }`}
  >
    {badgeCount > 0 && (
      <div className="absolute top-1 end-1/2 translate-x-4 w-5 h-5 bg-red-600 text-white text-xs font-bold rounded-full flex items-center justify-center border-2 border-stone-800">
        {badgeCount}
      </div>
    )}
    {icon}
    <span className="text-xs font-medium mt-1">{label}</span>
  </button>
);


export const MobileNav: React.FC<MobileNavProps> = ({ activeTab, setActiveTab, scenesCount, t }) => {
    
  const handleTabChange = (tab: 'form' | 'preview') => {
      if (activeTab !== tab) {
        playSound('click');
        setActiveTab(tab);
      }
  }
  
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-stone-900/80 backdrop-blur-lg border-t border-amber-700/30 shadow-lg z-30 flex">
      <NavButton
        label={t('controlPanel')}
        icon={<MagicWandIcon className="w-6 h-6" />}
        isActive={activeTab === 'form'}
        onClick={() => handleTabChange('form')}
      />
      <div className="w-px bg-amber-700/30"></div>
      <NavButton
        label={t('previewTitle')}
        icon={<BookIcon className="w-6 h-6" />}
        isActive={activeTab === 'preview'}
        onClick={() => handleTabChange('preview')}
        badgeCount={scenesCount}
      />
    </nav>
  );
};