import React from 'react';
import { BookIcon } from './icons/BookIcon';
import { playSound } from '../services/audioService';
import { HistoryIcon } from './icons/HistoryIcon';
import { UserIcon } from './icons/UserIcon';

interface HeaderProps {
  isVerified: boolean;
  onLogout: () => void;
  onNewStory: () => void;
  onOpenHistory: () => void;
  username: string | null;
  language: 'ar' | 'en';
  setLanguage: (lang: 'ar' | 'en') => void;
  // FIX: Updated the type of the `t` function to allow for an options object.
  t: (key: string, options?: any) => string;
}

export const Header: React.FC<HeaderProps> = (props) => {
  const isAdmin = props.username === 'admin';

  const handleLanguageChange = (lang: 'ar' | 'en') => {
    if (props.language !== lang) {
      playSound('click');
      props.setLanguage(lang);
    }
  };

  return (
    <header className="py-4 px-4 sm:px-8">
      <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center text-2xl sm:text-3xl font-bold text-stone-100 text-center sm:text-start">
          <BookIcon className="w-7 h-7 sm:w-8 sm:h-8 text-amber-400 me-3" />
          <h1>{props.t('appTitle')}</h1>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="flex items-center p-1 bg-stone-800/60 rounded-lg">
            <button
              onClick={() => handleLanguageChange('en')}
              className={`px-3 py-1 text-sm font-bold rounded-md transition-colors ${
                props.language === 'en' ? 'bg-amber-600 text-white' : 'text-stone-300 hover:bg-stone-700'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => handleLanguageChange('ar')}
              className={`px-3 py-1 text-sm font-bold rounded-md transition-colors ${
                props.language === 'ar' ? 'bg-amber-600 text-white' : 'text-stone-300 hover:bg-stone-700'
              }`}
            >
              AR
            </button>
          </div>
          {props.isVerified && (
            <>
              <button
                onClick={() => {
                  playSound('click');
                  props.onNewStory();
                }}
                className="bg-amber-600 text-white font-bold py-1 px-4 rounded-md hover:bg-amber-700 transition-colors duration-300 text-sm"
              >
                {props.t('newStory')}
              </button>
              <button
                onClick={() => {
                  playSound('open');
                  props.onOpenHistory();
                }}
                className="flex items-center bg-stone-700 text-white font-bold py-1 px-4 rounded-md hover:bg-stone-600 transition-colors duration-300 text-sm"
              >
                <HistoryIcon className="w-4 h-4 me-2" />
                {props.t('history')}
              </button>
              <div className="hidden sm:flex items-center text-green-400 font-semibold bg-green-900/50 py-1 px-3 rounded-lg text-sm">
                <UserIcon className="w-5 h-5 me-2" />
                <span>{props.username}</span>
                {isAdmin && (
                  <span className="ms-2 px-2 py-0.5 bg-amber-500 text-stone-900 rounded-full text-xs font-bold">
                    {props.t('admin')}
                  </span>
                )}
              </div>
              <button
                onClick={() => {
                  playSound('click');
                  props.onLogout();
                }}
                className="bg-stone-700 text-white font-bold py-1 px-4 rounded-md hover:bg-stone-600 transition-colors duration-300 text-sm"
              >
                {props.t('logout')}
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};