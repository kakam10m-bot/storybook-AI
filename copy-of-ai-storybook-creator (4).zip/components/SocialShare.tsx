import React, { useState } from 'react';
import { Tooltip } from './Tooltip';
import { TwitterIcon } from './icons/TwitterIcon';
import { FacebookIcon } from './icons/FacebookIcon';
import { LinkIcon } from './icons/LinkIcon';
import { CheckIcon } from './icons/CheckIcon';
import { playSound } from '../services/audioService';

interface SocialShareProps {
  storyTitle: string;
  t: (key: any, options?: any) => string;
}

const ShareButton: React.FC<{
  tooltip: string;
  onClick?: () => void;
  href?: string;
  children: React.ReactNode;
}> = ({ tooltip, onClick, href, children }) => {
  const commonProps = {
    className: "p-2 rounded-full bg-stone-800/60 text-stone-300 hover:bg-stone-700/80 hover:text-amber-400 transition-colors duration-200 border border-stone-700",
    onClick,
  };

  return (
    <Tooltip text={tooltip}>
      {href ? (
        <a {...commonProps} href={href} target="_blank" rel="noopener noreferrer">
          {children}
        </a>
      ) : (
        <button {...commonProps} type="button">
          {children}
        </button>
      )}
    </Tooltip>
  );
};

export const SocialShare: React.FC<SocialShareProps> = ({ storyTitle, t }) => {
  const [isCopied, setIsCopied] = useState(false);
  const appUrl = window.location.href;
  const shareText = t('shareText', { title: storyTitle });

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl).then(() => {
      setIsCopied(true);
      playSound('addScene');
      setTimeout(() => setIsCopied(false), 2000);
    }, (err) => {
      console.error('Failed to copy text: ', err);
      playSound('error');
    });
  };

  return (
    <div className="flex items-center gap-3">
        <span className="text-sm font-semibold text-stone-400">{t('shareLabel')}:</span>
        <div className="flex items-center gap-2">
            <ShareButton
                tooltip={t('shareOnX')}
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(appUrl)}`}
                onClick={() => playSound('export')}
            >
                <TwitterIcon className="w-5 h-5" />
            </ShareButton>
            <ShareButton
                tooltip={t('shareOnFacebook')}
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(appUrl)}`}
                onClick={() => playSound('export')}
            >
                <FacebookIcon className="w-5 h-5" />
            </ShareButton>
            <ShareButton
                tooltip={isCopied ? t('copiedTooltip') : t('copyLinkTooltip')}
                onClick={handleCopyLink}
            >
                {isCopied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <LinkIcon className="w-5 h-5" />}
            </ShareButton>
        </div>
    </div>
  );
};