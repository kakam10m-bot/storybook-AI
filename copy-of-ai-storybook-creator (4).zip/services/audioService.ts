// This service relies on the global Howl object from the Howler.js CDN script
declare const Howl: any;

const sounds = {
  click: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/switch-on.mp3'], volume: 0.7 }),
  addScene: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/ping.mp3'], volume: 0.5 }),
  export: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/swoosh.mp3'], volume: 0.7 }),
  delete: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/pop.mp3'], volume: 0.6 }),
  error: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/error.mp3'], volume: 0.6 }),
  open: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/ui-scroll.mp3'], volume: 0.8 }),
  close: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/ui-scroll.mp3'], volume: 0.8, rate: 0.9 }), // Play slightly different for closing
  suggest: new Howl({ src: ['https://cdn.jsdelivr.net/gh/k-next/sounds@main/sounds/chime.mp3'], volume: 0.5 }),
};

export type SoundType = keyof typeof sounds;

export const playSound = (sound: SoundType) => {
  try {
    if (sounds[sound] && typeof sounds[sound].play === 'function') {
      sounds[sound].play();
    }
  } catch (e) {
    console.error(`Could not play sound: ${sound}`, e);
  }
};
