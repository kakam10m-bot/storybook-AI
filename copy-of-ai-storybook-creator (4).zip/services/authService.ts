import type { User } from '../types';

const USERS_KEY = 'ai-storybook-users';

// --- Helper Functions ---

const getUsers = (): User[] => {
  try {
    const usersJson = localStorage.getItem(USERS_KEY);
    return usersJson ? JSON.parse(usersJson) : [];
  } catch (e) {
    console.error("Failed to parse users from localStorage", e);
    return [];
  }
};

const saveUsers = (users: User[]): void => {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch (e) {
    console.error("Failed to save users to localStorage", e);
  }
};


// --- Public Service Functions ---

/**
 * Registers a new user.
 * @param username The desired username.
 * @param password The desired password.
 * @param t The translation function.
 * @returns A promise that resolves with the new User object.
 * @throws An error if the username already exists or if credentials are too short.
 */
// FIX: Updated the type of the `t` function to allow for an options object.
export const registerUser = (username: string, password: string, t: (key: string, options?: any) => string): Promise<User> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => { // Simulate network delay
      const normalizedUsername = username.trim().toLowerCase();
      if (normalizedUsername === 'admin' || normalizedUsername === 'kakam10m') {
        return reject(new Error(t('errorUsernameNotAllowed')));
      }
      if (username.length < 3) {
        return reject(new Error(t('errorUsernameTooShort')));
      }
      if (password.length < 6) {
        return reject(new Error(t('errorPasswordTooShort')));
      }

      const users = getUsers();
      const existingUser = users.find(u => u.username.toLowerCase() === username.toLowerCase());

      if (existingUser) {
        return reject(new Error(t('errorUsernameExists')));
      }

      const newUser: User = { username, password }; // In a real app, hash the password here
      users.push(newUser);
      saveUsers(users);
      
      resolve(newUser);
    }, 500);
  });
};

/**
 * Logs in an existing user.
 * @param username The user's username.
 * @param password The user's password.
 * @param t The translation function.
 * @returns A promise that resolves with the User object if successful.
 * @throws An error if the user is not found or the password does not match.
 */
// FIX: Updated the type of the `t` function to allow for an options object.
export const loginUser = (username: string, password: string, t: (key: string, options?: any) => string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => { // Simulate network delay
            // Admin Check
            const adminPasscode = process.env.ADMIN_PASSCODE || '11223321';
            if (username.toLowerCase() === 'kakam10m') {
                if (password === adminPasscode) {
                    // We resolve with 'admin' as the username so the rest of the app
                    // can easily identify the admin user for UI elements like badges.
                    resolve({ username: 'admin', password: '' }); 
                } else {
                    reject(new Error(t('errorAdminPasscodeIncorrect')));
                }
                return; // Stop execution if it's an admin login attempt
            }

            // Regular User Check
            const users = getUsers();
            const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
            
            if (!user) {
                return reject(new Error(t('errorInvalidCredentials')));
            }

            // In a real app, you would compare a hashed password.
            if (user.password !== password) {
                 return reject(new Error(t('errorInvalidCredentials')));
            }

            resolve(user);
        }, 500);
    });
};