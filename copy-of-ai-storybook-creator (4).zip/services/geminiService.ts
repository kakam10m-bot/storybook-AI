import { GoogleGenAI, Modality, Type } from "@google/genai";
import type { Difficulty, Character } from '../types';

// Helper function to initialize the client and check for the API key on demand.
// This prevents the app from crashing on startup if the API key is not set.
const getAiClient = () => {
  const API_KEY = process.env.API_KEY;
  if (!API_KEY) {
    // This error will be caught by the calling function's try-catch block,
    // allowing for a graceful error message to the user.
    throw new Error("Invalid or missing API key. Please ensure it is configured correctly.");
  }
  return new GoogleGenAI({ apiKey: API_KEY });
};

export const generateImage = async (
  fullPrompt: string,
  aspectRatio: string,
  characterDescription: string,
  writeTextOnImage: boolean,
  textToWrite: string | undefined,
  lang: 'ar' | 'en',
  previousImageUrl?: string,
): Promise<string> => {
  try {
    const ai = getAiClient(); // Initialize on use
    
    const textInstruction = (writeTextOnImage && textToWrite)
      ? `\n\n**Crucial Final Instruction:** Inscribe the following ${lang === 'ar' ? 'Arabic' : 'English'} text onto the image. The text should be beautifully integrated into the artwork, using a legible and artistic storybook font: "${textToWrite}"`
      : '';

    if (previousImageUrl) {
      console.log("Using gemini-2.5-flash-image for consistency.");

      const match = previousImageUrl.match(/^data:(image\/.+);base64,(.+)$/);
      if (!match) {
        throw new Error("Invalid previous image URL format.");
      }
      const mimeType = match[1];
      const base64ImageData = match[2];

      let consistencyPrompt: string;
      if (characterDescription.trim()) {
        consistencyPrompt = `You are an expert illustrator focused on character consistency. Your goal is to draw the same character in a new situation.

1.  **Analyze the Character:**
    *   **Reference Image:** Look at the provided image to understand the character's face, hair, body shape, and artistic style.
    *   **Character Blueprint:** The core description is: "${characterDescription}". This is the source of truth for their permanent features.

2.  **Illustrate the New Scene:**
    *   **New Prompt:** Your main task is to draw the scene described here: "${fullPrompt}".

3.  **Crucial Instructions:**
    *   Place the **same character** into this **new scene**.
    *   The character's core identity (face, hair style, etc.) MUST remain consistent.
    *   However, their clothing, expression, and actions MUST adapt to the new scene described in the prompt. For example, if the prompt says they are swimming, they shouldn't be wearing their normal clothes from the previous scene unless specified.
    *   **Priority:** Your highest priority is to accurately illustrate the new scene's action and environment, while featuring the consistent character.`;
      } else {
        consistencyPrompt = `You are an expert illustrator focused on character consistency. Your goal is to draw the same character in a new situation.

1.  **Analyze the Character:**
    *   **Reference Image:** Look at the provided image to understand the character's face, hair, body shape, clothing, and the overall artistic style.

2.  **Illustrate the New Scene:**
    *   **New Prompt:** Your main task is to draw the scene described here: "${fullPrompt}".

3.  **Crucial Instructions:**
    *   Place the **same character** into this **new scene**.
    *   The character's core identity (face, hair style, etc.) MUST remain consistent.
    *   However, their expression and actions MUST adapt to the new scene described in the prompt. Their clothing should also adapt if the new scene requires it (e.g., swimming gear for a swimming scene).
    *   **Priority:** Your highest priority is to accurately illustrate the new scene's action and environment, while featuring the consistent character.`;
      }

      consistencyPrompt += textInstruction;

      // Corrected the 'contents' structure to be a single object with a 'parts' array for multi-modal input.
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64ImageData,
                mimeType: mimeType,
              },
            },
            { text: consistencyPrompt },
          ],
        },
        config: {
          responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
      });

      const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
      if (imagePart?.inlineData) {
        return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
      }
      throw new Error("Image generation failed: No image data returned from consistency model.");
    } else {
      const finalPrompt = fullPrompt + textInstruction;
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: finalPrompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: aspectRatio as any,
        },
      });

      if (!response.generatedImages || response.generatedImages.length === 0) {
        // This suggests a safety policy was triggered. The error handler in App.tsx can show a user-friendly message.
        throw new Error("Image generation failed due to safety policies. Please rephrase your prompt.");
      }
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    }
  } catch (error) {
    console.error("Error in generateImage:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate image: ${error.message}`);
    }
    throw new Error("An unknown error occurred during image generation.");
  }
};

export const generateStoryText = async (
  imagePrompt: string,
  storyTitle: string,
  difficulty: Difficulty,
  isAdultStory: boolean,
  characters: Character[],
  lang: 'ar' | 'en'
): Promise<string> => {
  try {
    const ai = getAiClient();
    const language = lang === 'ar' ? 'Arabic' : 'English';
    const adultContext = isAdultStory ? "The tone should be suitable for an adult audience, with more complex themes, but not graphic." : "The tone should be simple, charming, and suitable for a children's story.";
    const difficultyMap = {
      easy: 'Write a very simple, short paragraph with basic vocabulary.',
      medium: 'Write a detailed and engaging paragraph.',
      hard: 'Write a rich, descriptive paragraph with sophisticated vocabulary and complex sentences.',
    };
    const characterInstruction = characters.length > 0
      ? `Please use the following characters in the story where appropriate: ${characters.map(c => `${c.name} (${c.description})`).join(', ')}.`
      : '';

    const prompt = `You are a creative storyteller. Based on the following scene description, write a compelling story paragraph in ${language} for a book titled "${storyTitle}".
Scene Description: "${imagePrompt}"
Instructions:
1. ${difficultyMap[difficulty]}
2. ${adultContext}
3. ${characterInstruction}
4. The paragraph should be narrative text that would appear in a storybook. It must be in ${language}.
5. Do not describe the image, but narrate the events and feelings of the character in the scene.
6. Respond only with the story text in ${language}.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text.trim();

  } catch (error) {
    console.error("Error in generateStoryText:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate story text: ${error.message}`);
    }
    throw new Error("An unknown error occurred during story text generation.");
  }
};

export const generateCoverImage = async (storyTitle: string, referenceImageUrl: string, writeTextOnImage: boolean, lang: 'ar' | 'en'): Promise<string> => {
    try {
        const ai = getAiClient();
        
        const match = referenceImageUrl.match(/^data:(image\/.+);base64,(.+)$/);
        if (!match) {
            throw new Error("Invalid reference image URL format for cover generation.");
        }
        const mimeType = match[1];
        const base64ImageData = match[2];

        const textInstruction = writeTextOnImage
        ? `The cover MUST include the story title '${storyTitle}' written in an elegant, captivating, and magical font. The title should be integrated beautifully into the artwork.`
        : `Do NOT include any text, titles, or words on the cover. The focus should be entirely on the artwork.`;

        const prompt = `You are a book cover designer. Create a beautiful and captivating book cover for a story titled "${storyTitle}".
        Use the provided image as inspiration for the style, characters, and mood. The cover should be epic and visually striking, suitable for a storybook.
        ${textInstruction}
        The final image should look like a professional book cover illustration.`;

        // Corrected the 'contents' structure to be a single object with a 'parts' array for multi-modal input.
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
              parts: [
                {
                  inlineData: {
                    data: base64ImageData,
                    mimeType: mimeType,
                  },
                },
                { text: prompt },
              ],
            },
            config: {
              responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
        if (imagePart?.inlineData) {
            return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        }
        throw new Error("Cover image generation failed: No image data returned.");

    } catch (error) {
        console.error("Error in generateCoverImage:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate cover image: ${error.message}`);
        }
        throw new Error("An unknown error occurred during cover image generation.");
    }
};

export const generateSceneOutlines = async (
  batchPrompt: string,
  storyTitle: string,
  characterDescription: string,
  characters: Character[],
  difficulty: Difficulty,
  isAdultStory: boolean,
  numberOfScenes: number,
  lang: 'ar' | 'en'
): Promise<{ imagePrompt: string; storyText: string }[]> => {
  try {
    const ai = getAiClient();
    const language = lang === 'ar' ? 'Arabic' : 'English';
    const adultContext = isAdultStory ? "The story is for adults, so the themes can be more mature and the language more complex." : "The story is for children, so keep the scenes simple, safe, and positive.";
    const difficultyMap = {
      easy: 'simple vocabulary and short sentences',
      medium: 'engaging descriptions and standard vocabulary',
      hard: 'rich, descriptive language and sophisticated vocabulary',
    };
    
    const charDesc = characterDescription.trim() ? `The main character is described as: "${characterDescription}". Ensure this character is central to the scenes.` : "There is no specific main character description provided.";
    const charDetails = characters.length > 0 
      ? `The story also involves these characters: ${characters.map(c => `${c.name} (${c.description})`).join('; ')}. Make sure to use their names in the 'storyText' and refer to them and their descriptions in the 'imagePrompt'.` 
      : '';

    const prompt = `You are a master storyteller and illustrator's assistant. Your task is to break down a story idea into ${numberOfScenes} distinct scenes for a storybook titled "${storyTitle}".
    
    Story Idea: "${batchPrompt}"
    
    Instructions:
    1.  Create a sequence of ${numberOfScenes} scenes that logically follow the story idea.
    2.  For each scene, provide two things:
        a.  'storyText': A paragraph of narrative text for the storybook. This text should use ${difficultyMap[difficulty]}. It must be in ${language}.
        b.  'imagePrompt': A detailed visual description for an AI illustrator to create an image for that scene. This prompt should be in English and focus on visual elements, actions, and the environment. ${charDesc}
    3.  ${charDetails}
    4.  ${adultContext}
    5.  Ensure the story flows logically from one scene to the next.
    6.  Return the output as a JSON array of objects.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                storyText: {
                  type: Type.STRING,
                  description: `The narrative text for the scene, in ${language}.`,
                },

                imagePrompt: {
                  type: Type.STRING,
                  description: 'A detailed visual prompt for the AI illustrator, in English.',
                },
              },
              required: ['storyText', 'imagePrompt'],
            },
          },
        },
    });

    const jsonStr = response.text.trim();
    const outlines = JSON.parse(jsonStr);
    
    if (!Array.isArray(outlines) || outlines.length === 0) {
      throw new Error("The AI did not return valid scene outlines.");
    }

    return outlines;

  } catch (error) {
    console.error("Error in generateSceneOutlines:", error);
    if (error instanceof Error) {
        if (error.name === 'SyntaxError') {
             throw new Error(`Failed to parse scene outlines from AI. The response was not valid JSON.`);
        }
        throw new Error(`Failed to generate scene outlines: ${error.message}`);
    }
    throw new Error("An unknown error occurred during scene outline generation.");
  }
};