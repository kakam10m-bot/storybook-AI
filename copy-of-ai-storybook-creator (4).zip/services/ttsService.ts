import type { Scene } from '../types';

interface SpeakStoryOptions {
  scenes: Scene[];
  onSceneStart: (sceneId: string) => void;
  onStoryEnd: () => void;
  onError: (error: string) => void;
  voiceURI?: string | null;
  lang: 'ar' | 'en';
}

let utteranceQueue: SpeechSynthesisUtterance[] = [];
let currentSceneIndex = -1;
let options: SpeakStoryOptions | null = null;
const synth = window.speechSynthesis;

// Stop any speaking when the page is reloaded or closed to prevent orphaned speech.
window.addEventListener('beforeunload', () => {
    if (synth.speaking || synth.paused) {
        synth.cancel();
    }
});


const speakNext = () => {
  if (currentSceneIndex >= 0 && currentSceneIndex < utteranceQueue.length) {
    const utterance = utteranceQueue[currentSceneIndex];
    utterance.onend = () => {
      currentSceneIndex++;
      speakNext();
    };
    utterance.onerror = (event) => {
        options?.onError(event.error || 'An unknown speech error occurred.');
        stop();
    };
    
    if (options && options.scenes[currentSceneIndex]) {
        options.onSceneStart(options.scenes[currentSceneIndex].id);
    }
    
    synth.speak(utterance);

  } else {
    // End of story
    options?.onStoryEnd();
    stop(); // Clean up
  }
};

export const start = (opts: SpeakStoryOptions) => {
  // Clear any previous narration
  if (synth.speaking || synth.paused) {
    synth.cancel();
  }
  
  options = opts;
  currentSceneIndex = 0;
  
  const voices = synth.getVoices();
  let selectedVoice: SpeechSynthesisVoice | null = null;
  
  // Find the selected voice, if provided
  if (options.voiceURI) {
    selectedVoice = voices.find(voice => voice.voiceURI === options.voiceURI) || null;
  }

  // If no specific voice is selected or found, find any voice for the target language as a fallback
  const finalVoice = selectedVoice || voices.find(voice => voice.lang.startsWith(options.lang)) || null;
  
  utteranceQueue = options.scenes.map(scene => {
    const utterance = new SpeechSynthesisUtterance(scene.description);
    utterance.lang = finalVoice ? finalVoice.lang : (options.lang === 'ar' ? 'ar-SA' : 'en-US');
    if(finalVoice) {
      utterance.voice = finalVoice;
    }
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    return utterance;
  });

  if (utteranceQueue.length > 0) {
    speakNext();
  } else {
    options.onStoryEnd();
  }
};

export const pause = () => {
  if (synth.speaking) {
    synth.pause();
  }
};

export const resume = () => {
  if (synth.paused) {
    synth.resume();
  }
};

export const stop = () => {
  if (synth.speaking || synth.paused) {
    synth.cancel();
  }
  utteranceQueue = [];
  currentSceneIndex = -1;
  options = null;
};

export const previewVoice = (
  voiceURI: string, 
  lang: 'ar' | 'en',
  onEndCallback?: () => void
) => {
  if (synth.speaking) {
    synth.cancel();
  }

  const voices = getVoices();
  const selectedVoice = voices.find(voice => voice.voiceURI === voiceURI);

  if (selectedVoice) {
    const sampleText = lang === 'ar' 
      ? "أهلاً بك في صانع القصص بالذكاء الاصطناعي."
      : "Welcome to the AI Storybook Creator.";
    const utterance = new SpeechSynthesisUtterance(sampleText);
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    
    utterance.onend = () => {
      onEndCallback?.();
    };
    
    utterance.onerror = (event) => {
      console.error('Speech synthesis error in preview:', event.error);
      onEndCallback?.();
    };

    synth.speak(utterance);
  } else {
    // If voice isn't found, callback immediately to prevent UI from getting stuck.
    onEndCallback?.();
  }
};

// It can take a moment for voices to load, so we might need this.
export const onVoicesChanged = (callback: () => void) => {
    synth.onvoiceschanged = callback;
}

export const getVoices = (): SpeechSynthesisVoice[] => {
    return synth.getVoices();
};